#!/bin/bash

source env.sh

docker-compose up
