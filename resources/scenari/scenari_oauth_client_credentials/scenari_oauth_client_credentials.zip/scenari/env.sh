export SERVER_FQDN=govway.localdomain
export LOCAL_DATA=./data
